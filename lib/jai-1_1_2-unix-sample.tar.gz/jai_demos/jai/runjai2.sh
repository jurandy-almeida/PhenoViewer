#!/bin/sh
#
# A script file to run the demo.
#

java -Xmx48m JAIExampleApp images/new_zealand.tif

