#PhenoViewer
Software de processamento e análise de imagens biológicas para o projeto e-Phenology

##Desenvolvedores
  * [Jurandy Gomes de Almeida Junior] (http://lattes.cnpq.br/4495269939725770)
  * [Héctor Castelli Zacharias] (http://lattes.cnpq.br/9639614559519495)

##Requisitos:
 * JAVA

#Funções:
 * Abrir séries de imagens
 * Máscaras de região
 * Exibir Histograma interativo das imagens abertas
 * Ler e mostrar um arquivo CSV com gŕaficos personalizados
