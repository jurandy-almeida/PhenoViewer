#!/bin/sh
#
# JMF->JAI interoperability demo
#
# The environment variables DEMO_DIR, JMFHOME, JAVAHOME, JAIHOME, and
# VIDEO_FILE must be defined by the user.
#
# Note that the JAI information does not need to be added to the various
# search paths if JAI is installed in the version of Java being used.

#
# Set the directory containing the demo class file
#
DEMO_DIR=

#
# Set JMF & JDK installation location 
#
JMFHOME=
JAVAHOME=
JAIHOME=

#
# Set the video file to be used
#
VIDEO_FILE=

#
# Add JMF jar files to the CLASSPATH
#
JMFCLASSPATH=.:$JMFHOME/lib/jmf.jar:$JMFHOME/lib/sound.jar:$JMFHOME/lib/multiplayer.jar:$JMFHOME/lib/mediaplayer.jar
JAICLASSPATH=$JAIHOME/jai_core.jar:$JAIHOME/jai_codec.jar:$JAIHOME/mlibwrapper_jai.jar
CLASSPATH=$DEMO_DIR:$JMFCLASSPATH:$JAICLASSPATH
export CLASSPATH

#
# Add JMF native libraries to LD_LIBRARY_PATH
#
LD_LIBRARY_PATH=.:$JMFHOME/lib:$JAIHOME:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

#
# Compile the demo source if it doesn't exist.
#
if [ ! -f "$DEMO_DIR/JMFToJAI.class" ]; then
    $JAVAHOME/bin/javac -deprecation JMFToJAI.java
fi

#
# Run the demo
#
exec $JAVAHOME/bin/java -Xmx128m JMFToJAI file:$VIDEO_FILE
