/**
 * @(#)JMFToJAI.java	15.2 03/05/20
 *
 * Copyright (c) 2003 Sun Microsystems, Inc.
 * All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * -Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * -Redistribution in binary form must reproduct the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * Neither the name of Sun Microsystems, Inc. or the names of contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * This software is provided "AS IS," without a warranty of any kind. ALL
 * EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
 * ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND ITS LICENSORS
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES. IN NO
 * EVENT WILL SUN OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE, PROFIT
 * OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR
 * PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF
 * LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN
 * IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 *
 * You acknowledge that Software is not designed,licensed or intended for
 * use in the design, construction, operation or maintenance of any nuclear
 * facility.
 */


import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.image.renderable.ParameterBlock;
import javax.media.jai.BorderExtender;
import javax.media.jai.ImageLayout;
import javax.media.jai.Interpolation;
import javax.media.jai.JAI;
import javax.media.jai.KernelJAI;
import javax.media.jai.PlanarImage;
import javax.media.jai.RasterFactory;
import javax.media.jai.TiledImage;
import javax.media.jai.widget.ScrollingImagePanel;
import javax.media.*;
import javax.media.control.FrameGrabbingControl;
import javax.media.control.FramePositioningControl;
import javax.media.format.RGBFormat;
import javax.media.format.VideoFormat;
import javax.media.protocol.*;
import javax.media.util.BufferToImage;


/**
 * Sample program to demonstate how image data may be transferred
 * from Java Media Framework (JMF) to Java Advanced Imaging (JAI) via
 * the intermediary of java.awt.Image objects.  Most of the JAI
 * processing occurs in the updateJAIImage() method.
 *
 * <p> It also demonstrates FramePositioningControl.
 *
 * <p> This code was adapted from the JMF demo 
 * <a href="http://java.sun.com/products/java-media/jmf/2.1.1/solutions/Seek.html">
 * Frame Seeking inside a Movie</a> in which the class was called
 * <code>Seek</code>.
 * 
 * <p> The user interface created by this class displays the movie on the
 * left and the JAI image on the right.  It contains several elements:
 * <ul>
 * <li>Buttons</li>
 * <ul>
 * <li>Forward - play the movie forwards.</li>
 * <li>Backward - play the movie backwards.</li>
 * <li>Pause - pause the movie.</li>
 * </ul>
 * <li>Scrollbar - amount to zoom the movie into the JAI frame.</li>
 * <li>CheckboxGroup - type of Interpolation to use for zooming.</li>
 * <li>Checkboxes
 * <ul>
 * <li>Invert - enables inversion in JMF->JAI conversion</li>
 * <li>Edge - enables Sobel edge detection in JMF->JAI conversion</li>
 * <li>Filter - enables embossing operation in JMF->JAI conversion</li>
 * </ul>
 * </ul>
 */


public class JMFToJAI extends Frame
    implements ControllerListener, AdjustmentListener,
               ActionListener, ItemListener {

    private static final int MAX_SCALE = 4;
    private static final int FACTOR = 10;

    Player p;
    FramePositioningControl fpc;
    FrameGrabbingControl fgc;
    Object waitSync = new Object();
    boolean stateTransitionOK = true;
    int totalFrames = FramePositioningControl.FRAME_UNKNOWN;

    BufferToImage frameConverter;
    PlanarImage jaiImage;

    Button fwdButton;
    Button bwdButton;
    Button rndButton;
    Checkbox invertBox;
    Checkbox edgeBox;
    Checkbox filterBox;
    ScrollingImagePanel imagePanel;
    CheckboxGroup interpBox;

    float scale = 1.0F;;
    boolean invert = false;
    boolean edge = false;
    boolean filter = false;
    Interpolation interp =
        Interpolation.getInstance(Interpolation.INTERP_NEAREST);

    int increment = 0;

    /**
     * Given a DataSource, create a player and use that player
     * as a player to playback the media.
     */


    public boolean open(DataSource ds) {

        setTitle("JMF->JAI Interoperability Demo");

	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent we) {
		System.exit(0);
	    }
	} );

	System.err.println("create player for: " + ds.getContentType());

	try {
	    p = Manager.createPlayer(ds);
	} catch (Exception e) {
	    System.err.println("Failed to create a player from the given DataSource: " + e);
	    return false;
	}

	p.addControllerListener(this);

	p.realize();
	if (!waitForState(p.Realized)) {
	    System.err.println("Failed to realize the player.");
	    return false;
	}

	// Try to retrieve a FramePositioningControl from the player.
	fpc = (FramePositioningControl)p.getControl("javax.media.control.FramePositioningControl");

	if (fpc == null) {
	    System.err.println("The player does not support FramePositioningControl.");
	    System.err.println("There's no reason to go on for the purpose of this demo.");
	    return false;
	}

	// Try to retrieve a FrameGrabbingControl from the player.
	fgc = (FrameGrabbingControl)p.getControl("javax.media.control.FrameGrabbingControl");

	if (fgc == null) {
	    System.err.println("The player does not support FrameGrabbingControl.");
	    System.err.println("There's no reason to go on for the purpose of this demo.");
	    return false;
	}

	Time duration = p.getDuration();

	if (duration != Duration.DURATION_UNKNOWN) {
	    System.err.println("Movie duration: " + duration.getSeconds());

	    totalFrames = fpc.mapTimeToFrame(duration);
	    if (totalFrames != FramePositioningControl.FRAME_UNKNOWN)
		System.err.println("Total # of video frames in the movies: " + totalFrames);
	    else
		System.err.println("The FramePositioningControl does not support mapTimeToFrame.");

	} else {
	    System.err.println("Movie duration: unknown"); 
	}
	
	// Prefetch the player.
	p.prefetch();
	if (!waitForState(p.Prefetched)) {
	    System.err.println("Failed to prefetch the player.");
	    return false;
	}

	// Display the visual & control component if there's one.
	setLayout(new FlowLayout());

	Panel cntlPanel = new Panel();
	Panel opPanel = new Panel();

	fwdButton = new Button("Forward");
	bwdButton = new Button("Backward");
	rndButton = new Button("Pause");

	fwdButton.addActionListener(this);
	bwdButton.addActionListener(this);
	rndButton.addActionListener(this);

        Scrollbar scaleBar =
            new Scrollbar(Scrollbar.HORIZONTAL, FACTOR, 1,
                          FACTOR, FACTOR*MAX_SCALE);
        scaleBar.addAdjustmentListener(this);

        CheckboxGroup cbg = new CheckboxGroup();
        Checkbox interpNNBox = new Checkbox("Nearest", cbg, true);
        Checkbox interpBLBox = new Checkbox("Bilinear", cbg, false);
        Checkbox interpBCBox = new Checkbox("Bicubic", cbg, false);

	interpNNBox.addItemListener(this);
	interpBLBox.addItemListener(this);
	interpBCBox.addItemListener(this);

        invertBox = new Checkbox("Invert");
        edgeBox = new Checkbox("Edge");
        filterBox = new Checkbox("Filter");

	invertBox.addItemListener(this);
	edgeBox.addItemListener(this);
	filterBox.addItemListener(this);

	cntlPanel.add(fwdButton);
	cntlPanel.add(bwdButton);
	cntlPanel.add(rndButton);

	opPanel.add(invertBox);
	opPanel.add(edgeBox);
	opPanel.add(filterBox);

	Component vc;
	if ((vc = p.getVisualComponent()) != null) {
	    add(vc);
	}

        Panel controlPanel = new Panel(new GridLayout(4, 1));
	controlPanel.add(cntlPanel);
	controlPanel.add(scaleBar);
        Panel interpPanel = new Panel();
        interpPanel.add(interpNNBox);
        interpPanel.add(interpBLBox);
        interpPanel.add(interpBCBox);
	controlPanel.add(interpPanel);
	controlPanel.add(opPanel);
        add(controlPanel);

        Buffer frame = fgc.grabFrame();
        VideoFormat format = (VideoFormat)frame.getFormat();
        frameConverter = new BufferToImage(format);
        scale = MAX_SCALE;
        updateJAIImage(frame);
        imagePanel = new ScrollingImagePanel(jaiImage,
                                             jaiImage.getWidth(),
                                             jaiImage.getHeight());
        scale = 1.0F;
        add(imagePanel);

	setVisible(true);

        boolean loop = true;
        while(loop) {
            fpc.skip(increment);
            updateJAIImage(fgc.grabFrame());
            imagePanel.set(jaiImage);
        }

	return true;
    }


    public void addNotify() {
	super.addNotify();
	pack();
    }


    /**
     * Block until the player has transitioned to the given state.
     * Return false if the transition failed.
     */


    boolean waitForState(int state) {
	synchronized (waitSync) {
	    try {
		while (p.getState() < state && stateTransitionOK)
		    waitSync.wait();
	    } catch (Exception e) {}
	}
	return stateTransitionOK;
    }

    public void actionPerformed(ActionEvent ae) {
	String command = ae.getActionCommand();
	if (command.equals("Forward")) {
            increment = 1;
	} else if (command.equals("Backward")) {
            increment = -1;
	} else if (command.equals("Pause")){
            increment = 0;
	}

        updateJAIImage(fgc.grabFrame());
        imagePanel.set(jaiImage);

	int currentFrame = fpc.mapTimeToFrame(p.getMediaTime());
	if (currentFrame != FramePositioningControl.FRAME_UNKNOWN)
	    System.err.println("Current frame: " + currentFrame);
    }

    public void adjustmentValueChanged(AdjustmentEvent e) {
        scale = (float)e.getAdjustable().getValue()/FACTOR;
    }

    public void itemStateChanged(ItemEvent e) {
        String label = (String)e.getItem();
        if(label.equals("Invert")) {
            invert = invertBox.getState();
        } else if(label.equals("Edge")) {
            edge = edgeBox.getState();
        } else if(label.equals("Filter")) {
            filter = filterBox.getState();
        } else if(label.equals("Nearest") &&
                  e.getStateChange() == ItemEvent.SELECTED) {
            interp = Interpolation.getInstance(Interpolation.INTERP_NEAREST);
        } else if(label.equals("Bilinear") &&
                  e.getStateChange() == ItemEvent.SELECTED) {
            interp = Interpolation.getInstance(Interpolation.INTERP_BILINEAR);
        } else if(label.equals("Bicubic") &&
                  e.getStateChange() == ItemEvent.SELECTED) {
            interp = Interpolation.getInstance(Interpolation.INTERP_BICUBIC);
        }
    }

    private void updateJAIImage(Buffer frame) {
        // Variable representing source image.
        RenderedImage src = null;

        // Create a BufferedImage source directly from JMF data if possible.
        if(frame.getFormat() instanceof RGBFormat &&
           (int[].class).isInstance(frame.getData())) {
            RGBFormat rgbFormat = (RGBFormat)frame.getFormat();
            int redMask = rgbFormat.getRedMask();
            int greenMask = rgbFormat.getGreenMask();
            int blueMask = rgbFormat.getBlueMask();
            if(rgbFormat.getBitsPerPixel() <= 32 &&
               rgbFormat.getPixelStride() == 1) {
                Dimension size = rgbFormat.getSize();
                SampleModel sm =
                    new SinglePixelPackedSampleModel(DataBuffer.TYPE_INT,
                                                     size.width, size.height,
                                                     rgbFormat.getLineStride(),
                                                     new int[] {redMask,
                                                                greenMask,
                                                                blueMask});
                int[] data = (int[])frame.getData();
                WritableRaster wr =
                    Raster.createWritableRaster(sm,
                                                new DataBufferInt(data,
                                                                  data.length),
                                                new Point(0, 0));
                ColorModel cm =
                    new DirectColorModel(32, redMask, greenMask, blueMask);
                src = new BufferedImage(cm, wr, false, null);
            }
        }

        // If an image couldn't be created directly use the AWT image route.
        if(src == null) {
            // Convert the Buffer to an AWT Image.
            Image frameImage = frameConverter.createImage(frame);

            // Derive a JAI image from the AWT image.
            src = JAI.create("AWTImage", frameImage);
        }

        // Ensure the source has a ComponentSampleModel.
        ParameterBlock pb;
        if(!(src.getSampleModel() instanceof ComponentSampleModel)) {
            SampleModel sampleModel =
                RasterFactory.createPixelInterleavedSampleModel(DataBuffer.TYPE_BYTE,
                                                                src.getWidth(),
                                                                src.getHeight(),
                                                                3);
            ImageLayout layout = new ImageLayout();
            layout.setSampleModel(sampleModel);
            //layout.setTileWidth(640).setTileHeight(480);
            RenderingHints hints =
                new RenderingHints(JAI.KEY_IMAGE_LAYOUT, layout);
            pb = (new ParameterBlock()).addSource(src);
            src = JAI.create("format", pb, hints);
        }

        // Scale the image by the specified factor.
        pb = (new ParameterBlock()).addSource(src);
        pb.add((float)scale).add((float)scale);
        if(imagePanel != null) {
            pb.add(-imagePanel.getWidth()/2.0F);
            pb.add(-imagePanel.getHeight()/2.0F);
        } else {
            pb.add(0.0F).add(0.0F);
        }
        pb.add(interp);
        BorderExtender extender =
            BorderExtender.createInstance(BorderExtender.BORDER_ZERO);
        RenderingHints hints =
            new RenderingHints(JAI.KEY_BORDER_EXTENDER, extender);
        jaiImage = JAI.create("Scale", pb, hints);

        // Invert the image if necessary.
        if(invert) {
            jaiImage = JAI.create("Invert", jaiImage);
        }

        // Calculate a gradient image if necessary.
        if(edge) {
            jaiImage = JAI.create("GradientMagnitude", jaiImage);
        }

        // Filter the image if necessary.
        if(filter) {
            float[] data = new float[] {-5.0F,        0.0F,        0.0F,
                                        0.0F,        1.0F,        0.0F,
                                        0.0F,        0.0F,        5.0F};
            KernelJAI kernel = new KernelJAI(3, 3, data);
            jaiImage = JAI.create("convolve", jaiImage, kernel);
        }
    }

    /**
     * Controller Listener.
     */


    public void controllerUpdate(ControllerEvent evt) {

	if (evt instanceof ConfigureCompleteEvent ||
	    evt instanceof RealizeCompleteEvent ||
	    evt instanceof PrefetchCompleteEvent) {
	    synchronized (waitSync) {
		stateTransitionOK = true;
		waitSync.notifyAll();
	    }
	} else if (evt instanceof ResourceUnavailableEvent) {
	    synchronized (waitSync) {
		stateTransitionOK = false;
		waitSync.notifyAll();
	    }
	} else if (evt instanceof EndOfMediaEvent) {
	    p.setMediaTime(new Time(0));
	    //p.start();
	    //p.close();
	    //System.exit(0);
	} else if (evt instanceof SizeChangeEvent) {
	}
    }



    /**
     * Main program
     */


    public static void main(String [] args) {

	if (args.length == 0) {
	    prUsage();
	    System.exit(0);
 	}

	MediaLocator ml;

	if ((ml = new MediaLocator(args[0])) == null) {
	    System.err.println("Cannot build media locator from: " + args[0]);
	    prUsage();
	    System.exit(0);
	}

	DataSource ds = null;

	// Create a DataSource given the media locator.
	try {
	    ds = Manager.createDataSource(ml);
	} catch (Exception e) {
	    System.err.println("Cannot create DataSource from: " + ml);
	    System.exit(0);
	}

	JMFToJAI seek = new JMFToJAI();
	if (!seek.open(ds))
	    System.exit(0);
    }

    static void prUsage() {
	System.err.println("Usage: java JMFToJAI <url>");
    }
}
